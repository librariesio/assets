These icons are completely free and you can use them in any project you want, personal or commercial; but please do not redistribute the icons themselves.

If you have any problems, want some other icons to be added or just want to get in contact, please email me at miu [at] linhpham.me or visit http://linhpham.me/

Thank you for your support!